import React from "react";
import RGrid from "custom components/RGrid";
import RCard from "custom components/RCard";

function FgTable() {
  return (
    <RGrid>
      <RCard>
        <h1>rex</h1>
      </RCard>
    </RGrid>
  );
}

export default FgTable;
