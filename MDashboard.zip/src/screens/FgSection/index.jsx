import React from "react";
import AccessibilityIcon from "@mui/icons-material/Accessibility";
import Inventory2Icon from "@mui/icons-material/Inventory2";
import DashboardNavbar from "examples/Navbars/DashboardNavbar";
import DashboardLayout from "examples/LayoutContainers/DashboardLayout";
import RGrid from "custom components/RGrid";
import RColumn from "custom components/RColumn";
import Card from "./StatsCards/Card";

function FgSection() {
  return (
    <DashboardLayout>
      <DashboardNavbar />
      <RGrid marginTop={20}>
        <h4>Overview</h4>
      </RGrid>
      <RGrid marginTop={12}>
        <RColumn>
          <Card
            child={<Inventory2Icon fontSize="large" />}
            value="20"
            label="Total Products"
            bgColor="#31859D"
          />
        </RColumn>
        <RColumn>
          <Card
            child={<AccessibilityIcon fontSize="large" />}
            value="203532%"
            label="RexRandy"
            bgColor="#FE7549"
          />
        </RColumn>
        <RColumn>
          <Card
            child={<AccessibilityIcon fontSize="large" />}
            value="203532%"
            label="RexRandy"
            bgColor="#7757FA"
          />
        </RColumn>
        <RColumn>
          <Card
            child={<AccessibilityIcon fontSize="large" />}
            value="203532%"
            label="RexRandy"
            bgColor="#2A76AA"
          />
        </RColumn>
      </RGrid>
      <RGrid marginTop={40}>
        <h4>Stocks Report</h4>
      </RGrid>
    </DashboardLayout>
  );
}

export default FgSection;
